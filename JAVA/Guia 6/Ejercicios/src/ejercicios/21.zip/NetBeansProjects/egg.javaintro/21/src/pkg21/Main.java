package pkg21;

import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author Federico Sorgi
 */
public class Main {

    public static void main(String[] args) {
        Scanner read = new Scanner(System.in).useDelimiter("\n");
        int[][] matrix10 = new int[10][10];
        int[][] matrix3 = new int[3][3];
        int[][] Matrix3 = new int[3][3];
        String[] index = new String[9];
        boolean equals = false;
        int value;
        
        //Lleno la matriz de 10*10
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                matrix10[i][j] = (int) (Math.random()*10);
            }
        }
        
        //Se muestra la matriz de 10*10
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(" " + matrix10[i][j] + " ");
            }
            System.out.println("");
        }
        
        //Se carga la matriz a buscar
        System.out.println(" ");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println("Ingresar un valor a buscar:");
                matrix3[i][j] = read.nextInt();
            }
        }
        
        //Se busca la matriz
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if(matrix10[i][j] == matrix3[0][0] && (10-i-3) > -1  && (10-j-3) > -1){
                    value = 0;
                    for (int k = 0; k < 3; k++) {
                        for (int l = 0; l < 3; l++) {
                            Matrix3[0+k][0+l] = matrix10[i+k][j+l];
                            index[value] =  (i+k) +  "-" + (j+l);
                            value++;
                        }
                    }
                }
                if(Arrays.deepEquals(Matrix3,matrix3)){
                    equals = true;
                    break;
                }
            }
        }
        
        System.out.println("");
        if(equals){
            System.out.print("Se encontro en los indices:");
            for (int i = 0; i < 9; i++) {
                System.out.print(index[i] + " ");
            }
        }else{
            System.out.println("No se encontro.");
        }

    }
    
}
