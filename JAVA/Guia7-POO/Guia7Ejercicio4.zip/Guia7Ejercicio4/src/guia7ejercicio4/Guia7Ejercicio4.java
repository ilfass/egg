
package guia7ejercicio4;

import guia7ejercicio4.Rectangulo.Rectangulos;
import guia7ejercicio4.Rectangulo.Servicios;

public class Guia7Ejercicio4 {

    public static void main(String[] args) {
       Rectangulos B1 = new Rectangulos();
      
       Servicios.crearRectangulo(B1);
       Servicios.calcularRectangulo(B1);
       Servicios.perimetroRectangulo(B1);
       Servicios.asteriscosRectangulo(B1);
       
               
    }
    
}
