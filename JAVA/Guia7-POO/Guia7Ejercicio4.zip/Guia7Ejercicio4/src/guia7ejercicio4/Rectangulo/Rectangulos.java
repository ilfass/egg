
package guia7ejercicio4.Rectangulo;

public class Rectangulos {
    private int base;
    private int altura;
    
    public void crearRectangulo(){
    }

    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }
    
    
}

