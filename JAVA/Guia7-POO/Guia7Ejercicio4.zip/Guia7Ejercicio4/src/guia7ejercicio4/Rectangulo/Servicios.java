package guia7ejercicio4.Rectangulo;

import java.util.Scanner;

public class Servicios {

    public static void crearRectangulo(Rectangulos rect1) {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese Base");
        rect1.setBase(leer.nextInt());
        System.out.println("Ingrese Altura");
        rect1.setAltura(leer.nextInt());

    }

    public static void calcularRectangulo(Rectangulos rect1) {

        int aux = rect1.getBase() * rect1.getAltura();
        System.out.println("El area es igual a " + aux);

    }

    public static void perimetroRectangulo(Rectangulos rect1) {

        int aux1 = (rect1.getBase() + rect1.getAltura()) * 2;
        System.out.println("El perimetro es igual a " + aux1);

    }

    public static void asteriscosRectangulo(Rectangulos rect1) {

        int bas = (rect1.getBase());
        int alt = (rect1.getAltura());

        for (int i = 0; i < alt; i++) {
            for (int j = 0; j < bas; j++) {
                if (i == 0 || i == alt - 1 || j == 0 || j == bas - 1) {
                    System.out.print("*");

                } else {
                    System.out.print(" ");
                }

            }

            System.out.println("");

        }

    }

}
