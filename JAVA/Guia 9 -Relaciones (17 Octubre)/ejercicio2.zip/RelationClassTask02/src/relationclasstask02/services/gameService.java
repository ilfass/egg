/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relationclasstask02.services;

import java.util.ArrayList;
import relationclasstask02.entity.Game;
import relationclasstask02.entity.Player;
import relationclasstask02.entity.waterPistol;

/**
 *
 * @author Exequiel Hordt
 * @version 18 Oct 2022
 */
public class gameService {

    private Game game = new Game();
    private Player player;
    private playerService pS = new playerService();
    private waterPistolService wPS = new waterPistolService();

    public void fillGame(ArrayList<Player> players, waterPistol wP) {
        game.setPlayers(players);
        game.setwP(wP);
    }

    public void round() {
        for (Player player : game.getPlayers()) {
            pS.shoot(game.getwP());
            if (player.isWet()) {
                System.out.println("The player " + player.getName() + " is wet");
                break;
            }
        }
    }
}
