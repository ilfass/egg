/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relationclasstask02.services;

import relationclasstask02.entity.Game;
import relationclasstask02.entity.waterPistol;

/**
 *
 * @author Exequiel Hordt
 * @version 18 Oct 2022
 */
public class waterPistolService {

    private Game game;
    private waterPistol waterP;

    public void fillPistol(waterPistol waterP) {
        
        waterP.setActualPosition((int) (Math.random() * 6) + 1);
        waterP.setWaterPosition((int) (Math.random() * 6) + 1);
    }

    public boolean wet() {
        return game.getwP().getActualPosition() == game.getwP().getWaterPosition();
    }

    public void nextJet() {
        if (waterP.getActualPosition() < 6) {
            waterP.setActualPosition(waterP.getActualPosition() + 1);
        } else {
            waterP.setActualPosition(1);
        }
    }

    public void showInfo() {
        System.out.println(waterP);
    }
}
