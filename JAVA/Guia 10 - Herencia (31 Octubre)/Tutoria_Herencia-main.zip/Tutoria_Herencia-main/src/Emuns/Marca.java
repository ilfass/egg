/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Emuns;

import sun.rmi.runtime.Log;

/**
 *
 * @author Gaston Rojas
 */
public enum Marca {
    
    SAMSUNG,LG,TOSHIBA,LENOVO,DELL,HP,INTEL;
    
}
